/**
 * Contains classes for the extraction and modelling of MP3 file metadata.
 */
package com.drew.metadata.mp3;
