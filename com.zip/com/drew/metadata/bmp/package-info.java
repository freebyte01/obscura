/**
 * Contains classes for the extraction and modelling of BMP file metadata.
 *
 * @since 2.7.0
 */
package com.drew.metadata.bmp;
