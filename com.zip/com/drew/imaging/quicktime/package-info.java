/**
 * Contains classes for working with QuickTime files.
 */
package com.drew.imaging.quicktime;
