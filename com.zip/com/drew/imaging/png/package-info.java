/**
 * Contains classes for working with PNG (Portable Network Graphic) files.
 *
 * @since 2.7.0
 */
package com.drew.imaging.png;
