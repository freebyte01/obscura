/**
 * Contains classes for working with MP3 files.
 */
package com.drew.imaging.mp3;
