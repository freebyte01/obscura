/**
 * Contains classes for working with GIF files.
 */
package com.drew.imaging.gif;
